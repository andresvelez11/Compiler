﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CompilerProyect
{
    class Symbol
    {
        string symbol;
        int recurrence;
        string type1;
        string type2;
        string type3;

        public Symbol()
        {
            
        }

        public String getSymbol()
        {
            return symbol;
        }

        public int getRecurrence()
        {
            return recurrence;
        }

        public void setSymbol(String symbol)
        {
            this.symbol = symbol;
        }

        public void setRecurrence(int recurrence)
        {
            this.recurrence = recurrence;
        }

    }
}
