﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Data;

namespace CompilerProyect
{
    class LexicalAnalyzer
    {
        static int howManyTimes(List<String> symbolsList, string symbol)//Counts the occurrences of a symbol in the table 
        {
            int times = 0;
            for (int i = 0; i < symbolsList.Count; i++)
            {
                if (symbolsList[i].Equals(symbol) == true)
                {
                    times = times + 1;
                }
            }
            return times;
        }

        static List<String> symbolTable(string code, List<int> recurrence, List<string> location) //Reads the code in string form and creates a table of symbols
        {
            char[] separators = { ' ', '{', '}', ';', '[', ']', '(', ')', '<', '>', '*', '+', '-', '/', ':', '=', '.', '_', '"', '\'' };
            string symbol = "";
            List<string> symbolsList = new List<string>();
            int lineCounter = 1;
            char lastSymbol = '0';
            for (int i = 0; i < code.Length; i++)
            {
                if (i > 0)
                {
                    lastSymbol = code[i - 1];
                }
                if (separators.Contains(code[i]) == true)
                {
                    if (String.IsNullOrEmpty(symbol) == false)
                    {
                        if (howManyTimes(symbolsList, symbol) == 0)
                        {
                            symbolsList.Add(symbol);
                            recurrence.Add(1);
                            location.Add("Lines: " + lineCounter.ToString() + " ");
                            symbol = null;
                        }
                        else
                        {
                            recurrence[symbolsList.IndexOf(symbol)] += 1;
                            location[symbolsList.IndexOf(symbol)] += lineCounter.ToString() + " ";
                            symbol = null;
                        }
                    }

                    if (code[i] != ' ')
                    {
                        if (code[i] != '\r')
                        {
                            if (code[i] != '\n')
                            {
                                if (lastSymbol != 'r')
                                {
                                    if (howManyTimes(symbolsList, code[i].ToString()) == 0)
                                    {
                                        recurrence.Add(1);
                                        symbolsList.Add(code[i].ToString());
                                        location.Add("Lines: " + lineCounter.ToString() + " ");
                                    }
                                    else
                                    {
                                        location[symbolsList.IndexOf(code[i].ToString())] += lineCounter.ToString() + " ";
                                        recurrence[symbolsList.IndexOf(code[i].ToString())] += 1;
                                    }
                                }
                            }
                        }
                    }
                }
                else if (code[i] != '\r')
                {
                    if (code[i] != '\n')
                    {
                        if (lastSymbol != 'r')
                        {
                            symbol = symbol + code[i].ToString();
                        }
                    }
                }
                else
                {
                    lineCounter += 1;
                }
            }
            return symbolsList;
        }

        static string[] readSymbols(string file)
        {
            string[] lines = File.ReadAllLines(file);

            return lines;
        }
        static string[] readSource(string file)
        {
            string[] lines = File.ReadAllLines(file);

            return lines;
        }

        static List<string> symbolType(List<string> sL, string[] symbols)
        {
            List<string> symbolT = new List<string>();
            string tipos = null;
            string[] line;
            int i = -1;
            line = symbols[0].Split(' ');

           

            for (int x = 0; x < sL.Count; x++)
            {
                while (sL[x].Equals(line[0]) == false && ++i < symbols.Length)
                {
                    line = symbols[i].Split(' ');

                }
                if (i < symbols.Length)
                {
                    for (int j = 1; j < line.Length; j++)
                    {
                        tipos = tipos + " " + line[j];
                    }
                    symbolT.Add(tipos);
                }
                else
                {

                    symbolT.Add("Variable Funtion");
                }
                i = 0;
                tipos = null;
            }


            return symbolT;
        }

        static List<string> tokenType(List<string> sL, string[] symbols)
        {
            List<string> symbolT = new List<string>();
            string tipos = null;
            string[] line;
            int i = -1;
            line = symbols[0].Split(' ');

            

            for (int x = 0; x < sL.Count; x++)
            {
                while (sL[x].Equals(line[0]) == false && ++i < symbols.Length)
                {
                    line = symbols[i].Split(' ');

                }
                if (i < symbols.Length)
                {
                    for (int j = 2; j < line.Length; j++)
                    {
                        tipos = tipos + " " + line[j];
                    }
                    symbolT.Add(tipos);
                }
                else
                {
                    
                    symbolT.Add("Variable");
                }
                i = 0;
                tipos = null;
            }


            return symbolT;
        }
        static List<string> tokenIds(List<string> sL, string[] symbols)
        {
            List<string> tokenId = new List<string>();
            string tipos = null;
            string[] line;
            int i = -1;
            line = symbols[0].Split(' ');

            int contador = 58;

            for (int x = 0; x < sL.Count; x++)
            {
                while (sL[x].Equals(line[0]) == false && ++i < symbols.Length)
                {
                    line = symbols[i].Split(' ');

                }
                if (i < symbols.Length)
                {
                    
                    
                        tipos = line[1];
                    
                    tokenId.Add(tipos);
                }
                else
                {
                    contador++;
                    tokenId.Add(contador.ToString());
                    
                }
                i = 0;
                tipos = null;
            }


            return tokenId;
        }

        public static string FormatCSV(string input)
        {
            try
            {
                if (input == null)
                    return string.Empty;

                bool containsQuote = false;
                bool containsComma = false;
                int len = input.Length;
                for (int i = 0; i < len && (containsComma == false || containsQuote == false); i++)
                {
                    char ch = input[i];
                    if (ch == '"')
                        containsQuote = true;
                    else if (ch == ',')
                        containsComma = true;
                }

                if (containsQuote && containsComma)
                    input = input.Replace("\"", "\"\"");

                if (containsComma)
                    return "\"" + input + "\"";
                else
                    return input;
            }
            catch
            {
                throw;
            }
        }

        public static void compares(List<string> token, List<string> tokenID)
        {
            
            for (int x = 0; x < tokenID.Count; x++)
            {
                for (int i = 0; i < token.Count; i++)
                {
                    if (token[x] == token[i])
                    {
                        tokenID[i] = tokenID[x];
                    }

                }

            }
        }


        static void Main(string[] args)
        {
            List<string> symbolsList = new List<string>();
            List<int> recurrence = new List<int>();
            List<string> tipos = new List<string>();
            List<string> location = new List<string>();

            List<string> token = new List<string>();
            List<string> tokenId = new List<string>();


            string textFile = @"Recursos\\CompilerProyect\\SymbolsTable.txt";
            string textFile2 = @"Recursos\\CompilerProyect\\TokensTable.txt";
            string[] symbols = readSymbols(textFile);
            string[] tokens = readSymbols(textFile2);



            string sourceFile = @"Recursos\\CompilerProyect\\SourceCode.txt";
            string sourceCode = File.ReadAllText(sourceFile);

            symbolsList = symbolTable(sourceCode, recurrence, location);
            tipos = symbolType(symbolsList, symbols);

            token = tokenType(symbolsList, tokens);
            tokenId = tokenIds(symbolsList, tokens);
            compares(token, tokenId);




            /* for (int i = 0; i < symbolsList.Count; i++)
             {

                 //Console.WriteLine(i + " " + symbolsList[i] + " Quantity: " + recurrence[i] + " Types: " + tipos[i] + " " + location[i]);
                 Console.WriteLine(i + " " + symbolsList[i] + " " + tipos[i] + " ");
             }

             Console.ReadLine();*/

            DataTable dataTable = new DataTable();
            StringBuilder sb = new StringBuilder();
            dataTable.Columns.Add("Index");
            dataTable.Columns.Add("Symbol");
            dataTable.Columns.Add("Quantity");
            dataTable.Columns.Add("Types");
            dataTable.Columns.Add("Location");

            StringBuilder sb2 = new StringBuilder();
            DataTable dataTable2 = new DataTable();
            dataTable2.Columns.Add("Lexema");
            dataTable2.Columns.Add("ID");
            dataTable2.Columns.Add("Token");

            for (int i = 0; i < symbolsList.Count; i++)
            {
                dataTable.Rows.Add(i, symbolsList[i], recurrence[i], tipos[i], location[i]);
            }




            for (int i = 0; i < symbolsList.Count; i++)
            {
                dataTable2.Rows.Add("'" + symbolsList[i] + "'",tokenId[i], token[i]);
            }

            foreach (DataRow dr in dataTable.Rows)
            {
                foreach (DataColumn dc in dataTable.Columns)
                    sb.Append(FormatCSV(dr[dc.ColumnName].ToString()) + ",");
                sb.Remove(sb.Length - 1, 1);
                sb.AppendLine();
            }

            foreach (DataRow dr in dataTable2.Rows)
            {
                foreach (DataColumn dc in dataTable2.Columns)
                    sb2.Append(FormatCSV(dr[dc.ColumnName].ToString()) + ",");
                sb2.Remove(sb2.Length - 1, 1);
                sb2.AppendLine();
            }

            File.Delete(@"Recursos\\CompilerProyect\\Output.csv");
            File.WriteAllText(@"CompilerProyect\\Output.csv", sb.ToString());

            File.Delete(@"Recursos\\CompilerProyect\\Output2.csv");
            File.WriteAllText(@"Recursos\\CompilerProyect\\Output2.csv", sb2.ToString());


        }
    }

}
